import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../utils/app_theme.dart';

class UserAvatar extends StatelessWidget {
  final String avatarUrl;
  final double radius;
  final bool isLive;
  final bool showBorder;

  const UserAvatar({
    super.key,
    required this.avatarUrl,
    this.radius = 24,
    this.isLive = false,
    this.showBorder = false,
  });

  @override
  Widget build(BuildContext context) {
    Widget avatar = CircleAvatar(
      radius: radius,
      backgroundColor: AppTheme.bgCard,
      child: ClipOval(
        child: avatarUrl.isNotEmpty
            ? CachedNetworkImage(
                imageUrl: avatarUrl,
                width: radius * 2,
                height: radius * 2,
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => _defaultAvatar(),
              )
            : _defaultAvatar(),
      ),
    );

    if (showBorder || isLive) {
      avatar = Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: isLive
              ? const LinearGradient(
                  colors: [AppTheme.primary, AppTheme.accent],
                )
              : const LinearGradient(
                  colors: [AppTheme.bgCardLight, AppTheme.bgCardLight],
                ),
        ),
        child: avatar,
      );
    }

    if (isLive) {
      return Stack(
        children: [
          avatar,
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  color: AppTheme.primary,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'LIVE',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 7,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    }

    return avatar;
  }

  Widget _defaultAvatar() {
    return Container(
      color: AppTheme.bgCard,
      child: const Icon(Icons.person_rounded,
          color: AppTheme.textMuted),
    );
  }
}
