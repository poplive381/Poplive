import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/user_model.dart';

class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserCredential> signInWithEmail(
      String email, String password) async {
    return await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  Future<UserCredential> registerWithEmail({
    required String email,
    required String password,
    required String username,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    // Create Firestore user document
    await _db.collection('users').doc(credential.user!.uid).set({
      'username': username,
      'displayName': username,
      'avatarUrl': '',
      'bio': '',
      'followersCount': 0,
      'followingCount': 0,
      'diamonds': 0,
      'coins': 100, // welcome bonus
      'isVerified': false,
      'isLive': false,
      'createdAt': FieldValue.serverTimestamp(),
      'followers': [],
      'following': [],
    });

    await credential.user?.updateDisplayName(username);
    return credential;
  }

  Future<UserCredential?> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null;

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCredential =
        await _auth.signInWithCredential(credential);

    // Create user doc if new
    final userDoc = await _db
        .collection('users')
        .doc(userCredential.user!.uid)
        .get();

    if (!userDoc.exists) {
      await _db
          .collection('users')
          .doc(userCredential.user!.uid)
          .set({
        'username':
            googleUser.email.split('@').first,
        'displayName':
            googleUser.displayName ?? 'User',
        'avatarUrl': googleUser.photoUrl ?? '',
        'bio': '',
        'followersCount': 0,
        'followingCount': 0,
        'diamonds': 0,
        'coins': 100,
        'isVerified': false,
        'isLive': false,
        'createdAt': FieldValue.serverTimestamp(),
        'followers': [],
        'following': [],
      });
    }

    return userCredential;
  }

  Future<UserModel?> getUserProfile(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromFirestore(doc);
  }

  Stream<UserModel?> watchUserProfile(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .snapshots()
        .map((doc) => doc.exists ? UserModel.fromFirestore(doc) : null);
  }

  Future<void> updateProfile({
    String? displayName,
    String? bio,
    String? avatarUrl,
  }) async {
    final uid = currentUser?.uid;
    if (uid == null) return;

    final updates = <String, dynamic>{};
    if (displayName != null) updates['displayName'] = displayName;
    if (bio != null) updates['bio'] = bio;
    if (avatarUrl != null) updates['avatarUrl'] = avatarUrl;

    await _db.collection('users').doc(uid).update(updates);
    if (displayName != null) {
      await currentUser?.updateDisplayName(displayName);
    }
  }

  Future<void> toggleFollow(String targetUserId) async {
    final myId = currentUser?.uid;
    if (myId == null || myId == targetUserId) return;

    final myRef = _db.collection('users').doc(myId);
    final targetRef = _db.collection('users').doc(targetUserId);

    final myDoc = await myRef.get();
    final following = List<String>.from(
        (myDoc.data()?['following'] as List?)?.cast<String>() ?? []);

    final batch = _db.batch();
    if (following.contains(targetUserId)) {
      // Unfollow
      batch.update(myRef, {
        'following': FieldValue.arrayRemove([targetUserId]),
        'followingCount': FieldValue.increment(-1),
      });
      batch.update(targetRef, {
        'followers': FieldValue.arrayRemove([myId]),
        'followersCount': FieldValue.increment(-1),
      });
    } else {
      // Follow
      batch.update(myRef, {
        'following': FieldValue.arrayUnion([targetUserId]),
        'followingCount': FieldValue.increment(1),
      });
      batch.update(targetRef, {
        'followers': FieldValue.arrayUnion([myId]),
        'followersCount': FieldValue.increment(1),
      });
    }
    await batch.commit();
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
