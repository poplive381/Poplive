import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/gift_model.dart';

class GiftService {
  GiftService._();
  static final GiftService instance = GiftService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> sendGift({
    required String streamId,
    required String hostId,
    required GiftModel gift,
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) throw Exception('Not logged in');

    // Check user balance
    final userDoc = await _db.collection('users').doc(uid).get();
    final coins = userDoc.data()?['coins'] as int? ?? 0;

    if (coins < gift.coinCost) {
      throw Exception('Not enough coins');
    }

    final batch = _db.batch();

    // Deduct coins from sender
    batch.update(_db.collection('users').doc(uid), {
      'coins': FieldValue.increment(-gift.coinCost),
    });

    // Add diamonds to host
    batch.update(_db.collection('users').doc(hostId), {
      'diamonds': FieldValue.increment(gift.diamondValue),
    });

    // Record gift in stream
    batch.set(
      _db
          .collection('streams')
          .doc(streamId)
          .collection('gifts')
          .doc(),
      {
        'senderId': uid,
        'hostId': hostId,
        'giftId': gift.id,
        'giftName': gift.name,
        'giftEmoji': gift.emoji,
        'coinCost': gift.coinCost,
        'diamondValue': gift.diamondValue,
        'timestamp': FieldValue.serverTimestamp(),
      },
    );

    // Update stream heart count (visual effect)
    batch.update(_db.collection('streams').doc(streamId), {
      'heartCount': FieldValue.increment(gift.diamondValue),
    });

    await batch.commit();
  }

  Stream<List<Map<String, dynamic>>> watchGifts(String streamId) {
    return _db
        .collection('streams')
        .doc(streamId)
        .collection('gifts')
        .orderBy('timestamp', descending: false)
        .limitToLast(20)
        .snapshots()
        .map((snap) => snap.docs.map((d) => d.data()).toList());
  }
}
