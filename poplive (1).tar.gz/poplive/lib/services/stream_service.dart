import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/stream_model.dart';

class StreamService {
  StreamService._();
  static final StreamService instance = StreamService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// All active live streams
  Stream<List<StreamModel>> watchLiveStreams({String? category}) {
    Query query = _db
        .collection('streams')
        .where('isLive', isEqualTo: true)
        .orderBy('viewerCount', descending: true);

    if (category != null && category != 'For You') {
      query = query.where('category', isEqualTo: category);
    }

    return query.snapshots().map((snap) =>
        snap.docs.map((d) => StreamModel.fromFirestore(d)).toList());
  }

  /// Start a new live stream and return its ID
  Future<String> startStream({
    required String title,
    required String category,
    String thumbnailUrl = '',
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) throw Exception('Not logged in');

    final user =
        await _db.collection('users').doc(uid).get();
    final userData = user.data()!;

    final docRef = await _db.collection('streams').add({
      'hostId': uid,
      'hostName': userData['displayName'],
      'hostAvatar': userData['avatarUrl'],
      'title': title,
      'category': category,
      'thumbnailUrl': thumbnailUrl,
      'viewerCount': 0,
      'isLive': true,
      'startedAt': FieldValue.serverTimestamp(),
      'tags': [],
      'heartCount': 0,
    });

    // Update user's isLive status
    await _db.collection('users').doc(uid).update({'isLive': true});

    return docRef.id;
  }

  /// End the live stream
  Future<void> endStream(String streamId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    await _db.collection('streams').doc(streamId).update({
      'isLive': false,
      'endedAt': FieldValue.serverTimestamp(),
    });

    await _db.collection('users').doc(uid).update({'isLive': false});
  }

  /// Send a live comment
  Future<void> sendComment({
    required String streamId,
    required String text,
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final user = await _db.collection('users').doc(uid).get();
    final userData = user.data()!;

    await _db
        .collection('streams')
        .doc(streamId)
        .collection('comments')
        .add({
      'uid': uid,
      'username': userData['displayName'],
      'avatarUrl': userData['avatarUrl'],
      'text': text,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  /// Watch live comments
  Stream<List<Map<String, dynamic>>> watchComments(String streamId) {
    return _db
        .collection('streams')
        .doc(streamId)
        .collection('comments')
        .orderBy('timestamp', descending: false)
        .limitToLast(50)
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => d.data()).toList());
  }

  /// Increment viewer count when joining
  Future<void> joinStream(String streamId) async {
    await _db.collection('streams').doc(streamId).update({
      'viewerCount': FieldValue.increment(1),
    });
  }

  /// Decrement viewer count on leave
  Future<void> leaveStream(String streamId) async {
    await _db.collection('streams').doc(streamId).update({
      'viewerCount': FieldValue.increment(-1),
    });
  }

  /// Add a heart
  Future<void> sendHeart(String streamId) async {
    await _db.collection('streams').doc(streamId).update({
      'heartCount': FieldValue.increment(1),
    });
  }
}
