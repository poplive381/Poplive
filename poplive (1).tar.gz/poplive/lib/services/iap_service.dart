import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// In-App Purchase Service
/// Set up product IDs in Google Play Console / App Store Connect
class IAPService {
  IAPService._();
  static final IAPService instance = IAPService._();

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;

  // Product IDs — must match exactly in Google Play Console / App Store Connect
  static const Set<String> _productIds = {
    'coins_70',
    'coins_350',
    'coins_700',
    'coins_1400',
    'coins_3500',
    'coins_7000',
  };

  // Map product ID to coin amount
  static const Map<String, int> _coinsMap = {
    'coins_70': 70,
    'coins_350': 350 + 20,    // includes bonus
    'coins_700': 700 + 50,
    'coins_1400': 1400 + 100,
    'coins_3500': 3500 + 350,
    'coins_7000': 7000 + 1000,
  };

  List<ProductDetails> _products = [];
  bool _isAvailable = false;

  Future<void> initialize() async {
    _isAvailable = await _iap.isAvailable();
    if (!_isAvailable) return;

    // Listen to purchase updates
    final purchaseStream = _iap.purchaseStream;
    _purchaseSubscription = purchaseStream.listen(
      _onPurchaseUpdate,
      onError: (error) {
        // handle error
      },
    );

    await _loadProducts();
  }

  Future<void> _loadProducts() async {
    final response =
        await _iap.queryProductDetails(_productIds);
    _products = response.productDetails;
  }

  Future<void> purchaseCoins(String productId) async {
    if (!_isAvailable) {
      throw Exception('In-app purchases not available on this device');
    }

    final product = _products.firstWhere(
      (p) => p.id == productId,
      orElse: () => throw Exception(
          'Product $productId not found. Make sure it is configured in the store.'),
    );

    final purchaseParam = PurchaseParam(productDetails: product);
    await _iap.buyConsumable(purchaseParam: purchaseParam);
  }

  Future<void> _onPurchaseUpdate(
      List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        await _deliverCoins(purchase);
        await _iap.completePurchase(purchase);
      } else if (purchase.status == PurchaseStatus.error) {
        // Handle error
      }
    }
  }

  Future<void> _deliverCoins(PurchaseDetails purchase) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final coins = _coinsMap[purchase.productID] ?? 0;
    if (coins == 0) return;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({'coins': FieldValue.increment(coins)});

    // Record transaction
    await FirebaseFirestore.instance
        .collection('transactions')
        .add({
      'uid': uid,
      'productId': purchase.productID,
      'coins': coins,
      'purchaseId': purchase.purchaseID,
      'timestamp': FieldValue.serverTimestamp(),
      'platform': purchase.verificationData.source,
    });
  }

  void dispose() {
    _purchaseSubscription?.cancel();
  }
}
