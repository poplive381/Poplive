import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String username;
  final String displayName;
  final String avatarUrl;
  final String bio;
  final int followersCount;
  final int followingCount;
  final int diamonds; // virtual currency
  final int coins;
  final bool isVerified;
  final bool isLive;
  final DateTime createdAt;
  final List<String> followers;
  final List<String> following;

  const UserModel({
    required this.uid,
    required this.username,
    required this.displayName,
    required this.avatarUrl,
    required this.bio,
    required this.followersCount,
    required this.followingCount,
    required this.diamonds,
    required this.coins,
    required this.isVerified,
    required this.isLive,
    required this.createdAt,
    required this.followers,
    required this.following,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      username: data['username'] ?? '',
      displayName: data['displayName'] ?? '',
      avatarUrl: data['avatarUrl'] ?? '',
      bio: data['bio'] ?? '',
      followersCount: data['followersCount'] ?? 0,
      followingCount: data['followingCount'] ?? 0,
      diamonds: data['diamonds'] ?? 0,
      coins: data['coins'] ?? 100,
      isVerified: data['isVerified'] ?? false,
      isLive: data['isLive'] ?? false,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      followers: List<String>.from(data['followers'] ?? []),
      following: List<String>.from(data['following'] ?? []),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'username': username,
      'displayName': displayName,
      'avatarUrl': avatarUrl,
      'bio': bio,
      'followersCount': followersCount,
      'followingCount': followingCount,
      'diamonds': diamonds,
      'coins': coins,
      'isVerified': isVerified,
      'isLive': isLive,
      'createdAt': Timestamp.fromDate(createdAt),
      'followers': followers,
      'following': following,
    };
  }
}
