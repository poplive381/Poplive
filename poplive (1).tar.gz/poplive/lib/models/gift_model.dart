class GiftModel {
  final String id;
  final String name;
  final String emoji;
  final int coinCost;
  final int diamondValue;
  final String animationAsset;
  final GiftRarity rarity;

  const GiftModel({
    required this.id,
    required this.name,
    required this.emoji,
    required this.coinCost,
    required this.diamondValue,
    required this.animationAsset,
    required this.rarity,
  });

  static List<GiftModel> get allGifts => [
    const GiftModel(
      id: 'rose',
      name: 'Rose',
      emoji: '🌹',
      coinCost: 1,
      diamondValue: 1,
      animationAsset: '',
      rarity: GiftRarity.common,
    ),
    const GiftModel(
      id: 'heart',
      name: 'Heart',
      emoji: '❤️',
      coinCost: 5,
      diamondValue: 5,
      animationAsset: '',
      rarity: GiftRarity.common,
    ),
    const GiftModel(
      id: 'kiss',
      name: 'Kiss',
      emoji: '💋',
      coinCost: 10,
      diamondValue: 10,
      animationAsset: '',
      rarity: GiftRarity.uncommon,
    ),
    const GiftModel(
      id: 'crown',
      name: 'Crown',
      emoji: '👑',
      coinCost: 100,
      diamondValue: 100,
      animationAsset: '',
      rarity: GiftRarity.rare,
    ),
    const GiftModel(
      id: 'rocket',
      name: 'Rocket',
      emoji: '🚀',
      coinCost: 500,
      diamondValue: 500,
      animationAsset: '',
      rarity: GiftRarity.epic,
    ),
    const GiftModel(
      id: 'castle',
      name: 'Castle',
      emoji: '🏰',
      coinCost: 1000,
      diamondValue: 1000,
      animationAsset: '',
      rarity: GiftRarity.legendary,
    ),
    const GiftModel(
      id: 'sports_car',
      name: 'Sports Car',
      emoji: '🏎️',
      coinCost: 5000,
      diamondValue: 5000,
      animationAsset: '',
      rarity: GiftRarity.legendary,
    ),
    const GiftModel(
      id: 'yacht',
      name: 'Yacht',
      emoji: '🛥️',
      coinCost: 10000,
      diamondValue: 10000,
      animationAsset: '',
      rarity: GiftRarity.legendary,
    ),
  ];
}

enum GiftRarity { common, uncommon, rare, epic, legendary }

extension GiftRarityExtension on GiftRarity {
  String get label {
    switch (this) {
      case GiftRarity.common:
        return 'Common';
      case GiftRarity.uncommon:
        return 'Uncommon';
      case GiftRarity.rare:
        return 'Rare';
      case GiftRarity.epic:
        return 'Epic';
      case GiftRarity.legendary:
        return 'Legendary';
    }
  }

  int get color {
    switch (this) {
      case GiftRarity.common:
        return 0xFF9E9E9E;
      case GiftRarity.uncommon:
        return 0xFF4CAF50;
      case GiftRarity.rare:
        return 0xFF2196F3;
      case GiftRarity.epic:
        return 0xFF9C27B0;
      case GiftRarity.legendary:
        return 0xFFFFD700;
    }
  }
}
