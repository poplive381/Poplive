import 'package:cloud_firestore/cloud_firestore.dart';

class StreamModel {
  final String id;
  final String hostId;
  final String hostName;
  final String hostAvatar;
  final String title;
  final String category;
  final String thumbnailUrl;
  final int viewerCount;
  final bool isLive;
  final DateTime startedAt;
  final List<String> tags;
  final int heartCount;

  const StreamModel({
    required this.id,
    required this.hostId,
    required this.hostName,
    required this.hostAvatar,
    required this.title,
    required this.category,
    required this.thumbnailUrl,
    required this.viewerCount,
    required this.isLive,
    required this.startedAt,
    required this.tags,
    required this.heartCount,
  });

  factory StreamModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return StreamModel(
      id: doc.id,
      hostId: data['hostId'] ?? '',
      hostName: data['hostName'] ?? '',
      hostAvatar: data['hostAvatar'] ?? '',
      title: data['title'] ?? '',
      category: data['category'] ?? 'For You',
      thumbnailUrl: data['thumbnailUrl'] ?? '',
      viewerCount: data['viewerCount'] ?? 0,
      isLive: data['isLive'] ?? false,
      startedAt: (data['startedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      tags: List<String>.from(data['tags'] ?? []),
      heartCount: data['heartCount'] ?? 0,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'hostId': hostId,
      'hostName': hostName,
      'hostAvatar': hostAvatar,
      'title': title,
      'category': category,
      'thumbnailUrl': thumbnailUrl,
      'viewerCount': viewerCount,
      'isLive': isLive,
      'startedAt': Timestamp.fromDate(startedAt),
      'tags': tags,
      'heartCount': heartCount,
    };
  }

  StreamModel copyWith({
    int? viewerCount,
    bool? isLive,
    int? heartCount,
  }) {
    return StreamModel(
      id: id,
      hostId: hostId,
      hostName: hostName,
      hostAvatar: hostAvatar,
      title: title,
      category: category,
      thumbnailUrl: thumbnailUrl,
      viewerCount: viewerCount ?? this.viewerCount,
      isLive: isLive ?? this.isLive,
      startedAt: startedAt,
      tags: tags,
      heartCount: heartCount ?? this.heartCount,
    );
  }
}
