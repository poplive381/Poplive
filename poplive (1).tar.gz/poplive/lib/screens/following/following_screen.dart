import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';
import '../../models/stream_model.dart';
import '../../widgets/stream_card.dart';

class FollowingScreen extends StatelessWidget {
  const FollowingScreen({super.key});

  // Mock live following data
  static final List<Map<String, dynamic>> _followingLive = [
    {
      'name': 'Luna Star',
      'avatar': 'https://i.pravatar.cc/150?img=1',
      'isLive': true,
      'viewers': 12400,
    },
    {
      'name': 'ProGamer99',
      'avatar': 'https://i.pravatar.cc/150?img=2',
      'isLive': true,
      'viewers': 8930,
    },
    {
      'name': 'Melody Rose',
      'avatar': 'https://i.pravatar.cc/150?img=3',
      'isLive': false,
      'viewers': 0,
    },
    {
      'name': 'DanceKing',
      'avatar': 'https://i.pravatar.cc/150?img=4',
      'isLive': true,
      'viewers': 3210,
    },
    {
      'name': 'BeautyQueen',
      'avatar': 'https://i.pravatar.cc/150?img=6',
      'isLive': false,
      'viewers': 0,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final liveNow = _followingLive.where((f) => f['isLive'] == true).toList();
    final offline = _followingLive.where((f) => f['isLive'] == false).toList();

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Following'),
        actions: [
          IconButton(icon: const Icon(Icons.search_rounded), onPressed: () {}),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          // Live now section
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: AppTheme.liveRed,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    'Live Now',
                    style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '(${liveNow.length})',
                    style: const TextStyle(color: AppTheme.textMuted),
                  ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: SizedBox(
              height: 90,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: liveNow.length,
                itemBuilder: (context, index) {
                  final user = liveNow[index];
                  return _LiveFollowingAvatar(
                    name: user['name'],
                    avatarUrl: user['avatar'],
                    viewers: user['viewers'],
                  );
                },
              ),
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 16)),

          // Recent streams header
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Recent Streams',
                    style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text('See all',
                        style: TextStyle(color: AppTheme.primary)),
                  ),
                ],
              ),
            ),
          ),

          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final user = offline[index % offline.length];
                return _RecentStreamTile(
                  name: user['name'],
                  avatarUrl: user['avatar'],
                  subtitle: 'Streamed 2 hours ago • 5.2K viewers',
                );
              },
              childCount: offline.length * 2,
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
    );
  }
}

class _LiveFollowingAvatar extends StatelessWidget {
  final String name;
  final String avatarUrl;
  final int viewers;

  const _LiveFollowingAvatar({
    required this.name,
    required this.avatarUrl,
    required this.viewers,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              children: [
                Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [AppTheme.primary, AppTheme.accent],
                    ),
                  ),
                  child: CircleAvatar(
                    radius: 28,
                    backgroundImage: NetworkImage(avatarUrl),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 4, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.primary,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 7,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              name.split(' ').first,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 11,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _RecentStreamTile extends StatelessWidget {
  final String name;
  final String avatarUrl;
  final String subtitle;

  const _RecentStreamTile({
    required this.name,
    required this.avatarUrl,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: CircleAvatar(
        radius: 26,
        backgroundImage: NetworkImage(avatarUrl),
      ),
      title: Text(name,
          style: const TextStyle(
              color: AppTheme.textPrimary, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle,
          style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
      trailing: OutlinedButton(
        onPressed: () {},
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: AppTheme.primary),
          foregroundColor: AppTheme.primary,
          padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          minimumSize: Size.zero,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
        child: const Text('Notify', style: TextStyle(fontSize: 12)),
      ),
    );
  }
}
