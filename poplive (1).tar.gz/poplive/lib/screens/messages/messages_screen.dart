import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';
import '../../models/message_model.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final List<ChatConversation> _conversations = [
    ChatConversation(
      id: '1',
      otherUserId: 'u1',
      otherUserName: 'Luna Star',
      otherUserAvatar: 'https://i.pravatar.cc/150?img=1',
      lastMessage: 'Thank you for the gift!',
      lastMessageAt: DateTime.now().subtract(const Duration(minutes: 5)),
      unreadCount: 2,
      isOnline: true,
    ),
    ChatConversation(
      id: '2',
      otherUserId: 'u2',
      otherUserName: 'ProGamer99',
      otherUserAvatar: 'https://i.pravatar.cc/150?img=2',
      lastMessage: 'GG! Come watch my stream tonight',
      lastMessageAt: DateTime.now().subtract(const Duration(hours: 1)),
      unreadCount: 0,
      isOnline: true,
    ),
    ChatConversation(
      id: '3',
      otherUserId: 'u3',
      otherUserName: 'Melody Rose',
      otherUserAvatar: 'https://i.pravatar.cc/150?img=3',
      lastMessage: 'I sent you a friend request!',
      lastMessageAt: DateTime.now().subtract(const Duration(hours: 3)),
      unreadCount: 1,
      isOnline: false,
    ),
    ChatConversation(
      id: '4',
      otherUserId: 'u6',
      otherUserName: 'BeautyQueen',
      otherUserAvatar: 'https://i.pravatar.cc/150?img=6',
      lastMessage: 'New makeup tutorial is up!',
      lastMessageAt: DateTime.now().subtract(const Duration(days: 1)),
      unreadCount: 0,
      isOnline: false,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Messages'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () {},
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primary,
          labelColor: Colors.white,
          unselectedLabelColor: AppTheme.textMuted,
          tabs: const [
            Tab(text: 'Chats'),
            Tab(text: 'Notifications'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _ChatsList(conversations: _conversations),
          const _NotificationsList(),
        ],
      ),
    );
  }
}

class _ChatsList extends StatelessWidget {
  final List<ChatConversation> conversations;
  const _ChatsList({required this.conversations});

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    return '${diff.inDays}d';
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.only(top: 8, bottom: 80),
      itemCount: conversations.length,
      separatorBuilder: (_, __) =>
          const Divider(height: 1, indent: 76, color: AppTheme.bgCardLight),
      itemBuilder: (context, index) {
        final conv = conversations[index];
        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          leading: Stack(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundImage: NetworkImage(conv.otherUserAvatar),
              ),
              if (conv.isOnline)
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      color: AppTheme.online,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppTheme.bgDark, width: 2),
                    ),
                  ),
                ),
            ],
          ),
          title: Text(
            conv.otherUserName,
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
          subtitle: Text(
            conv.lastMessage,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: conv.unreadCount > 0
                  ? AppTheme.textPrimary
                  : AppTheme.textMuted,
              fontSize: 13,
            ),
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _timeAgo(conv.lastMessageAt),
                style: const TextStyle(
                    color: AppTheme.textMuted, fontSize: 11),
              ),
              const SizedBox(height: 4),
              if (conv.unreadCount > 0)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.primary,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${conv.unreadCount}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          onTap: () {},
        );
      },
    );
  }
}

class _NotificationsList extends StatelessWidget {
  const _NotificationsList();

  @override
  Widget build(BuildContext context) {
    final notifications = [
      {
        'icon': Icons.favorite_rounded,
        'color': AppTheme.primary,
        'text': 'Luna Star liked your comment',
        'time': '5m ago',
      },
      {
        'icon': Icons.person_add_rounded,
        'color': const Color(0xFF4FC3F7),
        'text': 'ProGamer99 started following you',
        'time': '1h ago',
      },
      {
        'icon': Icons.card_giftcard_rounded,
        'color': AppTheme.gold,
        'text': 'You received a Rose gift from MoonChild',
        'time': '2h ago',
      },
      {
        'icon': Icons.live_tv_rounded,
        'color': AppTheme.liveRed,
        'text': 'Melody Rose is now live!',
        'time': '3h ago',
      },
    ];

    return ListView.separated(
      padding: const EdgeInsets.only(top: 8, bottom: 80),
      itemCount: notifications.length,
      separatorBuilder: (_, __) =>
          const Divider(height: 1, indent: 60, color: AppTheme.bgCardLight),
      itemBuilder: (context, index) {
        final n = notifications[index];
        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: (n['color'] as Color).withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(n['icon'] as IconData,
                color: n['color'] as Color, size: 22),
          ),
          title: Text(
            n['text'] as String,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
          ),
          subtitle: Text(
            n['time'] as String,
            style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
          ),
        );
      },
    );
  }
}
