import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../utils/app_theme.dart';
import '../../models/gift_model.dart';

class WatchStreamScreen extends StatefulWidget {
  final String streamId;
  const WatchStreamScreen({super.key, required this.streamId});

  @override
  State<WatchStreamScreen> createState() => _WatchStreamScreenState();
}

class _WatchStreamScreenState extends State<WatchStreamScreen>
    with SingleTickerProviderStateMixin {
  final _commentController = TextEditingController();
  final _scrollController = ScrollController();
  late AnimationController _heartController;
  bool _isFollowing = false;
  int _heartCount = 45231;
  bool _showGiftPanel = false;

  final List<Map<String, dynamic>> _liveComments = [
    {'user': 'StarFan99', 'text': 'You look amazing tonight!', 'color': 0xFF4FC3F7},
    {'user': 'MoonChild', 'text': 'first!!!', 'color': 0xFFF06292},
    {'user': 'GiftKing', 'text': 'sent a Crown', 'isGift': true, 'color': 0xFFFFD700},
    {'user': 'NightOwl', 'text': 'Love this song!', 'color': 0xFFAED581},
    {'user': 'PopFan', 'text': 'Please sing "Stay"!', 'color': 0xFFBA68C8},
    {'user': 'Viewer123', 'text': 'This is fire!', 'color': 0xFFFF8A65},
  ];

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _heartController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _commentController.dispose();
    _scrollController.dispose();
    _heartController.dispose();
    super.dispose();
  }

  void _sendHeart() {
    setState(() => _heartCount++);
    _heartController.forward(from: 0);
  }

  void _sendComment() {
    final text = _commentController.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _liveComments.add({'user': 'You', 'text': text, 'color': 0xFFFFFFFF});
    });
    _commentController.clear();
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Video layer placeholder (Agora remote user view)
          Container(
            color: const Color(0xFF1A1A2E),
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.live_tv_rounded, size: 80, color: Colors.white24),
                  SizedBox(height: 12),
                  Text(
                    'Live Stream\n(Agora Video goes here)',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white38),
                  ),
                ],
              ),
            ),
          ),

          // Gradient overlay (bottom)
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black38, Colors.transparent, Colors.black87],
                  stops: [0, 0.4, 1],
                ),
              ),
            ),
          ),

          // Top bar
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 12,
            right: 12,
            child: Row(
              children: [
                // Host info
                CircleAvatar(
                  radius: 20,
                  backgroundImage:
                      const NetworkImage('https://i.pravatar.cc/150?img=1'),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Luna Star',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        '12.4K viewers',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                // Follow button
                GestureDetector(
                  onTap: () => setState(() => _isFollowing = !_isFollowing),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: _isFollowing
                          ? Colors.white24
                          : AppTheme.primary,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      _isFollowing ? 'Following' : '+ Follow',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // LIVE badge
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.liveRed,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    'LIVE',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Close
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black38,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close_rounded,
                        color: Colors.white, size: 18),
                  ),
                ),
              ],
            ),
          ),

          // Comments list
          Positioned(
            left: 12,
            right: 80,
            bottom: _showGiftPanel ? 340 : 80,
            height: 200,
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _liveComments.length,
              itemBuilder: (context, index) {
                final c = _liveComments[index];
                final isGift = c['isGift'] == true;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.black45,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '${c['user']}  ',
                            style: TextStyle(
                              color: Color(c['color'] as int),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                          if (isGift)
                            const TextSpan(text: '🎁 ', style: TextStyle(fontSize: 14))
                          else
                            const TextSpan(),
                          TextSpan(
                            text: c['text'] as String,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Right action buttons
          Positioned(
            right: 12,
            bottom: _showGiftPanel ? 360 : 100,
            child: Column(
              children: [
                _ActionBtn(
                  icon: Icons.share_rounded,
                  label: 'Share',
                  onTap: () {},
                ),
                const SizedBox(height: 16),
                _ActionBtn(
                  icon: Icons.card_giftcard_rounded,
                  label: 'Gift',
                  color: AppTheme.gold,
                  onTap: () => setState(() => _showGiftPanel = !_showGiftPanel),
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: _sendHeart,
                  child: Column(
                    children: [
                      const Icon(Icons.favorite_rounded,
                          color: AppTheme.primary, size: 32),
                      Text(
                        _formatCount(_heartCount),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Bottom input bar
          if (!_showGiftPanel)
            Positioned(
              left: 12,
              right: 12,
              bottom: MediaQuery.of(context).viewInsets.bottom + 16,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: TextField(
                        controller: _commentController,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 13),
                        decoration: const InputDecoration(
                          hintText: 'Say something...',
                          hintStyle: TextStyle(
                              color: Colors.white38, fontSize: 13),
                          border: InputBorder.none,
                          contentPadding:
                              EdgeInsets.symmetric(horizontal: 16),
                          fillColor: Colors.transparent,
                          filled: false,
                        ),
                        onSubmitted: (_) => _sendComment(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _sendComment,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: AppTheme.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.send_rounded,
                          color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),

          // Gift panel
          if (_showGiftPanel)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _GiftPanel(
                onClose: () => setState(() => _showGiftPanel = false),
              ),
            ),
        ],
      ),
    );
  }

  String _formatCount(int count) {
    if (count >= 1000000) return '${(count / 1000000).toStringAsFixed(1)}M';
    if (count >= 1000) return '${(count / 1000).toStringAsFixed(1)}K';
    return '$count';
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionBtn({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(color: Colors.white, fontSize: 10)),
        ],
      ),
    );
  }
}

class _GiftPanel extends StatefulWidget {
  final VoidCallback onClose;
  const _GiftPanel({required this.onClose});

  @override
  State<_GiftPanel> createState() => _GiftPanelState();
}

class _GiftPanelState extends State<_GiftPanel> {
  GiftModel? _selectedGift;
  final int _userCoins = 1500;

  @override
  Widget build(BuildContext context) {
    final gifts = GiftModel.allGifts;
    return Container(
      height: 320,
      decoration: const BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle + header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(
              children: [
                const Text(
                  'Send a Gift',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const Spacer(),
                Row(
                  children: [
                    const Icon(Icons.monetization_on_rounded,
                        color: AppTheme.gold, size: 16),
                    const SizedBox(width: 4),
                    Text(
                      '$_userCoins coins',
                      style: const TextStyle(
                          color: AppTheme.gold, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: widget.onClose,
                  child: const Icon(Icons.close_rounded,
                      color: AppTheme.textMuted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Gifts grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              scrollDirection: Axis.horizontal,
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.8,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
              ),
              itemCount: gifts.length,
              itemBuilder: (context, index) {
                final gift = gifts[index];
                final selected = _selectedGift?.id == gift.id;
                return GestureDetector(
                  onTap: () => setState(() => _selectedGift = gift),
                  child: Container(
                    decoration: BoxDecoration(
                      color: selected
                          ? AppTheme.primary.withOpacity(0.2)
                          : AppTheme.bgCardLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: selected
                            ? AppTheme.primary
                            : Colors.transparent,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(gift.emoji, style: const TextStyle(fontSize: 28)),
                        const SizedBox(height: 4),
                        Text(
                          gift.name,
                          style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.monetization_on_rounded,
                                size: 10, color: AppTheme.gold),
                            const SizedBox(width: 2),
                            Text(
                              '${gift.coinCost}',
                              style: const TextStyle(
                                  color: AppTheme.gold, fontSize: 10),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Send button
          Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              height: 44,
              child: ElevatedButton(
                onPressed: _selectedGift != null
                    ? () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                'Sent ${_selectedGift!.emoji} ${_selectedGift!.name}!'),
                            backgroundColor: AppTheme.primary,
                          ),
                        );
                        widget.onClose();
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 44),
                ),
                child: Text(
                  _selectedGift != null
                      ? 'Send ${_selectedGift!.emoji} (${_selectedGift!.coinCost} coins)'
                      : 'Select a gift',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
