import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../../models/stream_model.dart';
import '../../utils/app_theme.dart';
import '../../widgets/stream_card.dart';
import '../../widgets/live_badge.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<String> _categories = [
    'For You',
    'New Star',
    'Gaming',
    'Music',
    'Dance',
    'Talk',
    'Beauty',
    'Sports',
  ];

  // Sample data (replace with Firestore stream)
  final List<StreamModel> _mockStreams = [
    StreamModel(
      id: '1',
      hostId: 'u1',
      hostName: 'Luna Star',
      hostAvatar: 'https://i.pravatar.cc/150?img=1',
      title: 'Night vibes with me ✨',
      category: 'For You',
      thumbnailUrl: 'https://picsum.photos/seed/s1/400/600',
      viewerCount: 12400,
      isLive: true,
      startedAt: DateTime.now().subtract(const Duration(hours: 1)),
      tags: ['music', 'chill'],
      heartCount: 45000,
    ),
    StreamModel(
      id: '2',
      hostId: 'u2',
      hostName: 'ProGamer99',
      hostAvatar: 'https://i.pravatar.cc/150?img=2',
      title: 'Ranked grind | Road to Grandmaster',
      category: 'Gaming',
      thumbnailUrl: 'https://picsum.photos/seed/s2/400/600',
      viewerCount: 8930,
      isLive: true,
      startedAt: DateTime.now().subtract(const Duration(minutes: 45)),
      tags: ['gaming', 'esports'],
      heartCount: 23000,
    ),
    StreamModel(
      id: '3',
      hostId: 'u3',
      hostName: 'Melody Rose',
      hostAvatar: 'https://i.pravatar.cc/150?img=3',
      title: 'Acoustic session 🎸',
      category: 'Music',
      thumbnailUrl: 'https://picsum.photos/seed/s3/400/600',
      viewerCount: 5620,
      isLive: true,
      startedAt: DateTime.now().subtract(const Duration(minutes: 30)),
      tags: ['music', 'acoustic'],
      heartCount: 18000,
    ),
    StreamModel(
      id: '4',
      hostId: 'u4',
      hostName: 'DanceKing',
      hostAvatar: 'https://i.pravatar.cc/150?img=4',
      title: 'Hip hop practice — join me!',
      category: 'Dance',
      thumbnailUrl: 'https://picsum.photos/seed/s4/400/600',
      viewerCount: 3210,
      isLive: true,
      startedAt: DateTime.now().subtract(const Duration(minutes: 15)),
      tags: ['dance', 'hiphop'],
      heartCount: 9800,
    ),
    StreamModel(
      id: '5',
      hostId: 'u5',
      hostName: 'StarNewbie',
      hostAvatar: 'https://i.pravatar.cc/150?img=5',
      title: 'First stream! Come say hi',
      category: 'New Star',
      thumbnailUrl: 'https://picsum.photos/seed/s5/400/600',
      viewerCount: 412,
      isLive: true,
      startedAt: DateTime.now().subtract(const Duration(minutes: 5)),
      tags: ['new', 'hello'],
      heartCount: 1200,
    ),
    StreamModel(
      id: '6',
      hostId: 'u6',
      hostName: 'BeautyQueen',
      hostAvatar: 'https://i.pravatar.cc/150?img=6',
      title: 'Makeup tutorial + Q&A',
      category: 'Beauty',
      thumbnailUrl: 'https://picsum.photos/seed/s6/400/600',
      viewerCount: 7840,
      isLive: true,
      startedAt: DateTime.now().subtract(const Duration(hours: 2)),
      tags: ['beauty', 'makeup'],
      heartCount: 32000,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverAppBar(
            backgroundColor: AppTheme.bgDark,
            floating: true,
            snap: true,
            title: Row(
              children: [
                RichText(
                  text: const TextSpan(
                    children: [
                      TextSpan(
                        text: 'Pop',
                        style: TextStyle(
                          color: AppTheme.primary,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      TextSpan(
                        text: 'Live',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search_rounded),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.notifications_rounded),
                onPressed: () {},
              ),
              const SizedBox(width: 4),
            ],
            bottom: TabBar(
              controller: _tabController,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicatorColor: AppTheme.primary,
              indicatorWeight: 3,
              indicatorSize: TabBarIndicatorSize.label,
              labelColor: Colors.white,
              unselectedLabelColor: AppTheme.textMuted,
              labelStyle: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
              unselectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 14,
              ),
              dividerColor: AppTheme.bgCardLight,
              tabs: _categories.map((c) => Tab(text: c)).toList(),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: _categories.map((category) {
            final streams = category == 'For You'
                ? _mockStreams
                : _mockStreams
                    .where((s) => s.category == category)
                    .toList();
            return _StreamGrid(streams: streams);
          }).toList(),
        ),
      ),
    );
  }
}

class _StreamGrid extends StatelessWidget {
  final List<StreamModel> streams;
  const _StreamGrid({required this.streams});

  @override
  Widget build(BuildContext context) {
    if (streams.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.live_tv_rounded,
                color: AppTheme.textMuted, size: 64),
            const SizedBox(height: 16),
            Text(
              'No streams yet',
              style: Theme.of(context)
                  .textTheme
                  .bodyLarge
                  ?.copyWith(color: AppTheme.textMuted),
            ),
            const SizedBox(height: 8),
            Text(
              'Be the first to go live!',
              style: Theme.of(context)
                  .textTheme
                  .bodySmall,
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.65,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
      ),
      itemCount: streams.length,
      itemBuilder: (context, index) => StreamCard(stream: streams[index]),
    );
  }
}
