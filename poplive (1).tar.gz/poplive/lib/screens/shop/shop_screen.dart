import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';
import '../../services/iap_service.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  bool _isLoading = false;

  // Coin packages matching your Google Play IAP product IDs
  static const List<_CoinPackage> _packages = [
    _CoinPackage(
      productId: 'coins_70',
      coins: 70,
      price: '\$0.99',
      bonus: 0,
      label: 'Starter',
      color: 0xFF9E9E9E,
    ),
    _CoinPackage(
      productId: 'coins_350',
      coins: 350,
      price: '\$4.99',
      bonus: 20,
      label: 'Popular',
      color: 0xFF4FC3F7,
    ),
    _CoinPackage(
      productId: 'coins_700',
      coins: 700,
      price: '\$9.99',
      bonus: 50,
      label: 'Value',
      color: 0xFF81C784,
    ),
    _CoinPackage(
      productId: 'coins_1400',
      coins: 1400,
      price: '\$19.99',
      bonus: 100,
      label: 'Best Deal',
      color: 0xFFFFB300,
    ),
    _CoinPackage(
      productId: 'coins_3500',
      coins: 3500,
      price: '\$49.99',
      bonus: 350,
      label: 'Big Fan',
      color: 0xFFFF7043,
    ),
    _CoinPackage(
      productId: 'coins_7000',
      coins: 7000,
      price: '\$99.99',
      bonus: 1000,
      label: 'Super Fan',
      color: 0xFFFFD700,
    ),
  ];

  Future<void> _purchase(_CoinPackage package) async {
    setState(() => _isLoading = true);
    try {
      await IAPService.instance.purchaseCoins(package.productId);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Purchase failed: $e'),
              backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Buy Coins'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          // Balance banner
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A1A3E), Color(0xFF2A1A3E)],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.bgCardLight),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.gold.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.monetization_on_rounded,
                      color: AppTheme.gold, size: 28),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Your Balance',
                      style: TextStyle(
                          color: AppTheme.textMuted, fontSize: 12),
                    ),
                    const Text(
                      '1,500 Coins',
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text(
                      'Diamonds',
                      style: TextStyle(
                          color: AppTheme.textMuted, fontSize: 12),
                    ),
                    Row(
                      children: [
                        const Icon(Icons.diamond_rounded,
                            color: Color(0xFF64B5F6), size: 16),
                        const SizedBox(width: 4),
                        const Text(
                          '230',
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),

          // How coins work
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _HowItem(
                  icon: Icons.monetization_on_rounded,
                  color: AppTheme.gold,
                  title: 'Buy Coins',
                  subtitle: 'with real money',
                ),
                const Icon(Icons.arrow_forward_rounded,
                    color: AppTheme.textMuted, size: 16),
                _HowItem(
                  icon: Icons.card_giftcard_rounded,
                  color: AppTheme.primary,
                  title: 'Send Gifts',
                  subtitle: 'to streamers',
                ),
                const Icon(Icons.arrow_forward_rounded,
                    color: AppTheme.textMuted, size: 16),
                _HowItem(
                  icon: Icons.diamond_rounded,
                  color: const Color(0xFF64B5F6),
                  title: 'Earn Diamonds',
                  subtitle: 'cash out',
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Select a Package',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Package grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 0.75,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
              ),
              itemCount: _packages.length,
              itemBuilder: (context, index) {
                final pkg = _packages[index];
                return GestureDetector(
                  onTap: _isLoading ? null : () => _purchase(pkg),
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.bgCardLight),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Label badge
                        if (pkg.label != 'Starter')
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Color(pkg.color).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              pkg.label,
                              style: TextStyle(
                                color: Color(pkg.color),
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )
                        else
                          const SizedBox(height: 16),
                        const SizedBox(height: 8),
                        const Icon(Icons.monetization_on_rounded,
                            color: AppTheme.gold, size: 32),
                        const SizedBox(height: 6),
                        Text(
                          '${pkg.coins}',
                          style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        if (pkg.bonus > 0)
                          Text(
                            '+${pkg.bonus} bonus',
                            style: TextStyle(
                              color: Color(pkg.color),
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        const SizedBox(height: 4),
                        Text(
                          pkg.price,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Purchases are processed by Google Play / App Store.\nCoins are non-refundable.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppTheme.textMuted, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}

class _HowItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;

  const _HowItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(title,
              style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 11,
                  fontWeight: FontWeight.w600)),
          Text(subtitle,
              style: const TextStyle(
                  color: AppTheme.textMuted, fontSize: 10)),
        ],
      ),
    );
  }
}

class _CoinPackage {
  final String productId;
  final int coins;
  final String price;
  final int bonus;
  final String label;
  final int color;

  const _CoinPackage({
    required this.productId,
    required this.coins,
    required this.price,
    required this.bonus,
    required this.label,
    required this.color,
  });
}
