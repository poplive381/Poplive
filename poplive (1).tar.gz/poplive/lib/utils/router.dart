import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../screens/shell_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/following/following_screen.dart';
import '../screens/live/go_live_screen.dart';
import '../screens/messages/messages_screen.dart';
import '../screens/profile/profile_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/live/watch_stream_screen.dart';
import '../screens/shop/shop_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/home',
  routes: [
    // Auth routes
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/register',
      builder: (context, state) => const RegisterScreen(),
    ),

    // Main shell with bottom nav
    ShellRoute(
      builder: (context, state, child) => ShellScreen(child: child),
      routes: [
        GoRoute(
          path: '/home',
          builder: (context, state) => const HomeScreen(),
        ),
        GoRoute(
          path: '/following',
          builder: (context, state) => const FollowingScreen(),
        ),
        GoRoute(
          path: '/go-live',
          builder: (context, state) => const GoLiveScreen(),
        ),
        GoRoute(
          path: '/messages',
          builder: (context, state) => const MessagesScreen(),
        ),
        GoRoute(
          path: '/me',
          builder: (context, state) => const ProfileScreen(),
        ),
      ],
    ),

    // Stream viewer
    GoRoute(
      path: '/watch/:streamId',
      builder: (context, state) => WatchStreamScreen(
        streamId: state.pathParameters['streamId']!,
      ),
    ),

    // Shop
    GoRoute(
      path: '/shop',
      builder: (context, state) => const ShopScreen(),
    ),
  ],
);
