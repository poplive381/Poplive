class AppConstants {
  // Agora App ID — get from console.agora.io
  static const String agoraAppId = 'YOUR_AGORA_APP_ID';

  // Firestore collection names
  static const String usersCollection = 'users';
  static const String streamsCollection = 'streams';
  static const String messagesCollection = 'messages';
  static const String transactionsCollection = 'transactions';
  static const String commentsSubcollection = 'comments';
  static const String giftsSubcollection = 'gifts';

  // App config
  static const String appName = 'PopLive';
  static const String appVersion = '1.0.0';
  static const int maxStreamTitleLength = 60;
  static const int maxBioLength = 150;

  // Pagination
  static const int streamsPageSize = 20;
  static const int commentsPageSize = 50;
  static const int messagesPageSize = 30;

  // Coins
  static const int welcomeBonus = 100;
  static const double diamondToCashRate = 0.001; // 1000 diamonds = $1
}
