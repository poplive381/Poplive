# PopLive — Flutter Live Streaming App

A Bigo Live-style live streaming app built with Flutter 3.19+, Firebase, Agora RTC, and Google Play Billing.

---

## Project Structure

```
lib/
├── main.dart                   # App entry point
├── firebase_options.dart       # Firebase config (replace with your own)
├── models/
│   ├── stream_model.dart       # Live stream data
│   ├── user_model.dart         # User profile data
│   ├── message_model.dart      # Chat messages
│   └── gift_model.dart         # Virtual gifts
├── screens/
│   ├── shell_screen.dart       # Bottom nav shell
│   ├── home/home_screen.dart   # Home with streams grid
│   ├── following/              # Following tab
│   ├── live/
│   │   ├── go_live_screen.dart # Start a stream
│   │   └── watch_stream_screen.dart  # Watch a stream + gifts
│   ├── messages/               # DMs + notifications
│   ├── profile/                # User profile
│   ├── auth/                   # Login + Register
│   └── shop/shop_screen.dart   # Coin shop (IAP)
├── services/
│   ├── auth_service.dart       # Firebase Auth + Google Sign In
│   ├── stream_service.dart     # Firestore stream operations
│   ├── gift_service.dart       # Virtual gift transactions
│   └── iap_service.dart        # In-app purchases (Play Billing)
├── widgets/
│   ├── stream_card.dart        # Live stream thumbnail card
│   ├── live_badge.dart         # Animated LIVE badge
│   └── user_avatar.dart        # Avatar with live indicator
└── utils/
    ├── app_theme.dart          # Dark theme definition
    ├── router.dart             # go_router navigation
    ├── constants.dart          # App-wide constants
    └── formatters.dart         # Number/date formatting helpers
```

---

## Setup Instructions

### 1. Flutter SDK

Requires Flutter 3.19+ with null safety. Verify:

```bash
flutter doctor
flutter --version
```

### 2. Firebase Setup

1. Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Enable **Authentication** (Email/Password + Google)
3. Enable **Firestore Database**
4. Enable **Firebase Storage**
5. Enable **Firebase Cloud Messaging**
6. Add your Android & iOS apps to the Firebase project
7. Run `flutterfire configure` (install with `dart pub global activate flutterfire_cli`)
   - This auto-generates `lib/firebase_options.dart` and places `google-services.json` + `GoogleService-Info.plist`

Or manually replace the placeholder values in `lib/firebase_options.dart`.

### 3. Agora RTC (Live Streaming)

1. Sign up at [console.agora.io](https://console.agora.io)
2. Create a project, copy your **App ID**
3. Set it in `lib/utils/constants.dart`:
   ```dart
   static const String agoraAppId = 'YOUR_AGORA_APP_ID';
   ```
4. Implement the Agora channel join/leave logic in:
   - `lib/screens/live/go_live_screen.dart` — broadcaster side
   - `lib/screens/live/watch_stream_screen.dart` — viewer side

### 4. Google Play Billing (In-App Purchases)

1. In Google Play Console, create **In-App Products** (consumable) with these IDs:
   - `coins_70` — $0.99
   - `coins_350` — $4.99
   - `coins_700` — $9.99
   - `coins_1400` — $19.99
   - `coins_3500` — $49.99
   - `coins_7000` — $99.99

2. The IAP flow is in `lib/services/iap_service.dart`

### 5. Google Sign In (Android)

Add your SHA-1 fingerprint in Firebase Console → Project Settings → Android app.

Get SHA-1:
```bash
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

### 6. iOS URL Scheme

In `ios/Runner/Info.plist`, replace:
```xml
<string>com.googleusercontent.apps.YOUR_CLIENT_ID</string>
```
with your actual `REVERSED_CLIENT_ID` from `GoogleService-Info.plist`.

---

## Build

### Android AAB (for Play Store)

```bash
flutter pub get
flutter build appbundle --release
```

Output: `build/app/outputs/bundle/release/app-release.aab`

### Android APK (for testing)

```bash
flutter build apk --release
```

### iOS (Xcode required)

```bash
flutter build ipa
```

---

## Firestore Data Structure

```
users/{uid}
  username, displayName, avatarUrl, bio
  followersCount, followingCount
  diamonds, coins, isVerified, isLive
  followers[], following[]

streams/{streamId}
  hostId, hostName, hostAvatar
  title, category, thumbnailUrl
  viewerCount, heartCount, isLive
  startedAt, endedAt, tags[]
  comments/{commentId}
  gifts/{giftId}

messages/{conversationId}
  participants[], lastMessage, lastMessageAt

transactions/{txId}
  uid, productId, coins, purchaseId, timestamp
```

---

## Dependencies Added Beyond pubspec

Add `google-services.json` to `android/app/` (from Firebase Console).
Add `GoogleService-Info.plist` to `ios/Runner/` (from Firebase Console).

---

## Features

- **Home** — Live streams grid with categories (For You, Gaming, Music, Dance, Beauty, New Star, Sports)
- **Following** — See who's live, recent streams from followed users
- **Go Live** — Start broadcasting with camera/mic, title, category picker
- **Watch Stream** — Full-screen viewer with live chat, heart animations, gift panel
- **Gifts** — 8 virtual gifts (Rose to Yacht), coin-powered, coin→diamond economy
- **Messages** — DM inbox with unread badges, notification feed
- **Profile** — Stats (followers/following/likes), coin & diamond balance, shop link
- **Auth** — Email/password + Google Sign In via Firebase
- **Coin Shop** — 6 IAP packages via Google Play Billing / App Store
- **Dark Theme** — Full dark UI with brand colors (red #FF2D55, orange #FF6B35)
