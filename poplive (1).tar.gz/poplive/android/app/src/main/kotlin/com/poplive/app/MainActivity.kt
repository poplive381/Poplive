package com.poplive.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
